# -*- coding: utf-8 -*-
#
# Copyright (c) 2023~2025 Beijing Innovation Center of Humanoid Robotics. All rights reserved.
#
import websockets
from algo_tools.websocket.socket_server import BaseSocketServer
from algo_tools.utils.msg_monitor import MessageMonitor


class TaskSocketServer(BaseSocketServer):
    def __init__(self, 
                 host="localhost", 
                 port="9192",
                 task_path="/task", 
                 maxsize=1000,
                 recv_callback=None):
        super().__init__(host=host, 
                         port=port, 
                         path_2_handler={task_path: self.task_handler})
        
        assert recv_callback is None or callable(recv_callback)
        
        self.task_path = task_path
        self.maxsize = maxsize
        
        
        self._task_url = f"ws://{self.host}:{self.port}{self.task_path}"
        self._clients = set()
        
        self._task_monitor = MessageMonitor(
            maxsize=maxsize,
            recv_callback=recv_callback
        )
        self._task_monitor.start()
        
        # loop = asyncio.new_event_loop()
        # asyncio.set_event_loop(loop)
        
    def get_latest_task_msg(self, timeout = None):
        return self._task_monitor.get_latest_msg(timeout=timeout)
    
    def reset(self):
        super().reset()
        self._clients = set()
    
    def log_info(self):
        print(f"服务端已启动, Access by: \n1. Execute Control Task: {self._task_url}")
    
    def register_task_callback(self, callback):
        assert callable(callback)
        self._task_monitor.recv_callback = callback 

    async def task_handler(self, websocket):
        self._clients.add(websocket)
        print(f"客户端接入: {websocket.remote_address}")
        
        try:
            while self._running:
                # 监听消息，保持连接
                message = await websocket.recv()
                self._task_monitor.send({"message": message, "websocket": websocket})
        
        except (websockets.ConnectionClosed, websockets.exceptions.ConnectionClosedOK):
            print(f"客户端正常关闭: {websocket.remote_address}")
        finally:
            self._clients.remove(websocket)


if __name__ == "__main__":
    server = TaskSocketServer('localhost', 9192)
    # asyncio.run(server.start_server())
    server.start()
