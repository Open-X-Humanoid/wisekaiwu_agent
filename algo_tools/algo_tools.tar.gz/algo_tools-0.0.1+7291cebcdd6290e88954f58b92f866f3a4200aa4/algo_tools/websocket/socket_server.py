# -*- coding: utf-8 -*-
#
# Copyright (c) 2023~2025 Beijing Innovation Center of Humanoid Robotics. All rights reserved.
#
import asyncio
import websockets
import signal
import logging
logger = logging.getLogger()


# 优雅关闭服务器的辅助函数
def shutdown_server():
    logger.info("\nShutting down server...")
    # 停止当前运行的事件循环
    for task in asyncio.all_tasks():
        task.cancel()


async def check_connection_with_ping(websocket):
    try:
        await websocket.ping()  # Send a ping frame
        # If no exception is raised, the connection is alive
        print("WebSocket connection is alive.")
        return True
    except websockets.exceptions.ConnectionClosedError:
        print("Connection closed or unreachable.")
        return False
        
async def recv_msg(websocket, timeout=None):
    try:
        message = await asyncio.wait_for(websocket.recv(), timeout=timeout)
        return message
    except (asyncio.exceptions.TimeoutError, websockets.exceptions.ConnectionClosedError):
        logger.warning(f'recv_msg: 警告, 接收消息超时或网络断连: {websocket.remote_address}')
        return None
    except websockets.exceptions.ConnectionClosedOK:
        # logger.info(f'recv_msg: 提示, 语音服务端主动断开连接，客户端正常退出: {websocket.remote_address}')
        return None
    # except Exception as e:
    #     logger.error(f"recv_msg: Error: {e}")
    #     return None


async def send_msg(websocket, message: str):
    err_msg = f"send_msg: 连接已关闭，无法发送消息: {websocket.remote_address}"
    try:
        await websocket.send(message)
        # print(f"send_msg: {message}")
        # logger.info(f"send_msg: {message}")
    except websockets.exceptions.ConnectionClosedOK:
        logger.error(err_msg)
    except websockets.exceptions.ConnectionClosedError:
        logger.error(err_msg)
    # except Exception as e:
    #     logger.error(f"recv_msg: Error: {e}，无法发送消息: {websocket.remote_address}")
    #     return None


class BaseSocketServer:
    def __init__(self, 
                 host, 
                 port,
                 path_2_handler):
        self.host = host
        self.port = port
        self.path_2_handler = path_2_handler
        
        self._running = True
        
    def reset(self):
        self._running = True
    
    def send_msg(self, websocket, message: str):
        asyncio.get_event_loop().run_until_complete(send_msg(websocket, message))
    
    async def handler(self, websocket, path):
        handler = self.path_2_handler.get(path, None)
        if handler:
            await handler(websocket)
        else:
            print(f"Unknown request path:  {path}, from client: {websocket.remote_address}")

    def log_info(self):
        print(f"Server is running on ws://{self.host}:{self.port}")

    async def start_server(self):
        start_server = websockets.serve(self.handler, host=self.host, port=self.port)
        
        async with start_server:
            self.log_info()
            try:
                # 用信号保持服务器运行，代替 asyncio.Future()
                await asyncio.Event().wait()
            except asyncio.CancelledError:
                print("Server has been stopped.")
                
    def start(self):
        loop = asyncio.new_event_loop()
        
        # 注册 `Ctrl+C` 信号处理，便于正确结束loop，不会卡死在 websocket.recv() 等阻塞操作
        for signame in ('SIGINT', 'SIGTERM'):
            loop.add_signal_handler(getattr(signal, signame), shutdown_server)

        try:
            # 运行主程序
            loop.run_until_complete(self.start_server())
        except asyncio.CancelledError:
            pass
        finally:
            # 优雅地关闭事件循环
            loop.close()
            print("Server closed.") 

    def stop(self):
        self._running = False


if __name__ == "__main__":
    server = BaseSocketServer('localhost', 9192)
    # asyncio.run(server.start_server())
    server.start()
