# -*- coding: utf-8 -*-
#
# Copyright (c) 2023~2025 Beijing Innovation Center of Humanoid Robotics. All rights reserved.
#
import asyncio
import websockets
import time
# from algo_tools.utils.msg_monitor import MessageMonitor
from algo_tools.websocket.socket_server import recv_msg, send_msg
from algo_tools.utils import CYAN, RESET
import logging
logger = logging.getLogger()


class TaskClient:
    """任务客户端，负责给服务端发送指令和持续接收消息，和TaskServer配套。"""
    def __init__(self,
                 url = 'ws://localhost:9192/task',
                 recv_callback = None,
                 connect_timeout = 3.0, 
                 recv_timeout = 60.0):
        assert callable(recv_callback)
        
        self.url = url
        self.recv_callback = recv_callback
        self.connect_timeout = connect_timeout
        self.recv_timeout = recv_timeout
        
        # self.message_monitor = MessageMonitor(
        #     maxsize=maxsize
        # )
        
        self._running = False
    
    async def recv_message(self, websocket):
        """获取服务端返回的结果。"""
        while self._running:
            try:
                message = await asyncio.wait_for(websocket.recv(), timeout=self.recv_timeout)
                # logger.info(f"recv_message: result_msg: {result_msg}")
                
                # 注意注意：
                # - 不要在recv_callback做耗时高的操作（如超过1s），否则会阻塞websocket导致无法正常接收消息，最后导致websocket异常断开！
                # - 如要做高耗时任务，就把message放到消息队列里，见 algo_tools.utils.msg_monitor.py
                if self.recv_callback is not None:
                    wait_msg = self.recv_callback(message)
                    if not wait_msg:
                        break
            except asyncio.exceptions.TimeoutError:
                logger.warning(f'recv_msg: 警告, 超过 {self.recv_timeout}s 没有收到服务端的消息: {websocket.remote_address}')
                break
            except websockets.exceptions.ConnectionClosedError:
                logger.warning(f'recv_msg: 警告, 网络异常关闭: {websocket.remote_address}')
                break
            except websockets.exceptions.ConnectionClosedOK:
                logger.warning(f'recv_msg: 警告, 服务端主动断开连接: {websocket.remote_address}')
                break

    async def async_send_message(self, message: str):
        """给服务端发消息。"""
        try:
            async with websockets.connect(self.url, open_timeout=self.connect_timeout) as websocket:
                # 发送消息
                await send_msg(websocket, message)
                # 等待回复
                await self.recv_message(websocket=websocket)
        except (ConnectionRefusedError, asyncio.TimeoutError) as err:
            logger.error(f"send_message: {err}: 连接服务端超时，请确检查网络: {self.url}")
    
    def send_message(self, message: str):
        """给服务端发一次消息，然后持续接收结果。"""
        start_time = time.time()
        
        asyncio.get_event_loop().run_until_complete(self.async_send_message(message))
        
        cost = (time.time() - start_time) * 1000
        logger.info(CYAN + f"send_message: cost={cost:.1f}ms" + RESET)

    def start(self):
        self._running = True
        # self.message_monitor.start()
    
    def stop(self):
        # self.message_monitor.stop()
        self._running = False
