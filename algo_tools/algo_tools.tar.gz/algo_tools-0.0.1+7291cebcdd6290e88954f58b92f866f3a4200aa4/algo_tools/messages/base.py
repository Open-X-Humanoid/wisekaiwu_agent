# -*- coding: utf-8 -*-
#
# Copyright (c) 2023~2025 Beijing Innovation Center of Humanoid Robotics. All rights reserved.
#

import asyncio
import inspect
import json
import logging
import uuid
from abc import abstractmethod

import requests
import uvicorn
from fastapi import FastAPI

from algo_tools.utils.msg_monitor import MessageMonitor

logger = logging.getLogger(__name__)

class BaseMsgClient:
    """Base class for message handling clients.

    Provides core functionality for message processing, including:
    - Message monitoring and callback handling
    - Message preprocessing capabilities
    - Send message control (enable/disable)
    - Abstract methods for implementation by subclasses
    """

    def __init__(self,
                 maxsize=1000,
                 recv_callback=None,
                 msg_preprocessor=None,
                 enable_input=True,
                 enable_output=True):
        """Initialize BaseMsgClient with configuration parameters.

        Args:
            maxsize (int): Maximum size of message queue. Defaults to 1000.
            recv_callback (callable, optional): Callback function for received messages.
            msg_preprocessor (callable, optional): Function to preprocess messages before handling.
            enable_input (bool): Whether to enable message input. Defaults to True.
            enable_output (bool): Whether to enable message output. Defaults to True.

        Raises:
            AssertionError: If recv_callback or msg_preprocessor is provided but not callable.
        """
        if recv_callback is not None:
            assert callable(recv_callback), recv_callback
        if msg_preprocessor is not None:
            assert callable(msg_preprocessor), msg_preprocessor
        
        self.recv_callback = recv_callback
        self.maxsize = maxsize
        self.msg_preprocessor = msg_preprocessor
        self.enable_input = enable_input
        self.enable_output = enable_output
        
        self.message_monitor = MessageMonitor(maxsize=maxsize, recv_callback=recv_callback)

        self._cur_message = None
        self._send_message_enable = True
        self._step_id = 0
        self._message_id = None
        
        self._running = True
        
        loop = asyncio.new_event_loop()
        #注册 `Ctrl+C` 信号处理，便于正确结束loop，不会卡死在 websocket.recv() 等阻塞操作
        # for signame in ('SIGINT', 'SIGTERM'):
        #     loop.add_signal_handler(getattr(signal, signame), shutdown_server)
        asyncio.set_event_loop(loop)
        
    def reset(self):
        """Reset the client to its initial state.

        Clears current message, enables sending, resets running state,
        step ID, and message ID.
        """
        self._cur_message = None
        self._send_message_enable = True
        self._running = True
        self._step_id = 0
        self._message_id = None

    def register_callback(self, callback):
        """Register an asynchronous message processing callback.

        Args:
            callback (callable): The callback function to register for message processing.

        Raises:
            AssertionError: If callback is not callable.
        """
        assert callable(callback)
        self.recv_callback = callback
        # 更新
        self.message_monitor.recv_callback = callback
    
    def register_msg_preprocessor(self, msg_preprocessor):
        """Register a message preprocessor.

        Args:
            msg_preprocessor (callable): Function to preprocess messages before handling.

        Raises:
            AssertionError: If msg_preprocessor is not callable.
        """
        assert callable(msg_preprocessor)
        self.msg_preprocessor = msg_preprocessor

    def get_latest_msg(self, timeout=None):
        """Get the latest message.

        Args:
            timeout (float, optional): Timeout in seconds. Defaults to None (no timeout).

        Returns:
            The latest message received, or None if timeout occurs.
        """
        return self.message_monitor.get_latest_msg(timeout=timeout)

    @abstractmethod
    def start(self):
        """Start the message client.

        This method should be implemented by subclasses to initialize
        and start the message client operation.
        """
        pass

    @abstractmethod
    def stop(self):
        """Stop the message client.

        This method should be implemented by subclasses to gracefully
        stop the message client operation.
        """
        pass

    def pending_send_message(self):
        """Disable message sending."""
        self._send_message_enable = False

    def resume_send_message(self):
        """Enable message sending."""
        self._send_message_enable = True
    
    @abstractmethod
    async def send_message_once(self, text: str, **kwargs):
        """Send a single message asynchronously.

        Args:
            text (str): The message text to send.
            **kwargs: Additional keyword arguments for message sending.

        This method should be implemented by subclasses.
        """
        pass

    @abstractmethod
    def send_message(self, text: str, **kwargs):
        """Send a message synchronously.

        Args:
            text (str): The message text to send.
            **kwargs: Additional keyword arguments for message sending.

        This method should be implemented by subclasses.
        """
        pass
    
    @abstractmethod
    async def send_message_chunk(self, text: str, **kwargs):
        """Send a message chunk.

        Args:
            text (str): The message chunk text to send.
            **kwargs: Additional keyword arguments.

        Raises:
            NotImplementedError: This method is not implemented in the base class.
        """
        pass

    def set_current_message(self, message):
        """Set the current message context.

        Args:
            message: The message to set as current context.
        """
        self._cur_message = message
        self._step_id = 0
        self._message_id = uuid.uuid4().hex

    def get_msg_dict(self, message: str):
        """Convert message to dictionary format containing 'instruction' field.

        Args:
            message (str or dict): Message to convert. Can be JSON string or dict.

        Returns:
            dict: Message dictionary with 'instruction' field.

        Raises:
            AssertionError: If message doesn't contain 'instruction' field or is not str/dict.
        """
        if isinstance(message, str):
            msg_dict = json.loads(message)
        else:
            assert isinstance(message, dict)
            msg_dict = message
        assert "instruction" in msg_dict, msg_dict.keys()
        return msg_dict
    
    async def process_message(self, msg_dict: dict):
        """Process received message synchronously or asynchronously.

        Args:
            msg_dict (dict): Message dictionary to process.

        The method first applies message preprocessing if configured,
        then sends the processed message to the message monitor.
        Messages that are None after preprocessing are discarded.
        """
        if self.msg_preprocessor is not None:
            # 检查是否是异步函数
            if inspect.iscoroutinefunction(self.msg_preprocessor):
                msg_dict = await self.msg_preprocessor(msg_dict)
            else:
                msg_dict = self.msg_preprocessor(msg_dict)

        # 异步去处理消息
        # None则表示要丢弃这个消息 
        if msg_dict is not None:
            self.message_monitor.send(msg_dict)
        else:
            logger.debug(f"message is None, skip.")


class BaseFastAPIMsgClient(BaseMsgClient):
    """Base class for FastAPI-based message clients.

    Inherits from BaseMsgClient and adds FastAPI server functionality
    for handling HTTP/WebSocket messages.
    """

    def __init__(self,
                 host: str = "0.0.0.0",
                 port: int = 8164,
                 maxsize=1000,
                 result_url: str = None,
                 recv_callback=None,
                 msg_preprocessor=None,
                 enable_input: bool = True,
                 enable_output: bool = True):
        """Initialize BaseFastAPIMsgClient.

        Args:
            host (str): Host address for FastAPI server. Defaults to "0.0.0.0".
            port (int): Port for FastAPI server. Defaults to 8164.
            maxsize (int): Maximum size of message queue. Defaults to 1000.
            result_url (str, optional): URL for posting results.
            recv_callback (callable, optional): Callback for received messages.
            msg_preprocessor (callable, optional): Function for message preprocessing.
            enable_input (bool): Whether to enable message input. Defaults to True.
            enable_output (bool): Whether to enable message output. Defaults to True.
        """
        super().__init__(maxsize=maxsize, 
                         recv_callback=recv_callback,
                         msg_preprocessor=msg_preprocessor,
                         enable_input=enable_input,
                         enable_output=enable_output)
        
        self.app = FastAPI()
        self.host = host
        self.port = port
        self.result_url = result_url
        # 用于启动服务器
        self._run_thread = None

        self._initialize_routes()
    
    def _initialize_routes(self):
        """Initialize FastAPI routes if input is enabled."""
        if not self.enable_input:
            logger.info("input is disable")
            return
        self._register_routes()

    @abstractmethod
    def _register_routes(self):
        """Register FastAPI routes.

        This method should be implemented by subclasses to register
        specific HTTP/WebSocket routes for message handling.
        """
        pass
    
    @abstractmethod
    def get_msg_dict(self, message):
        """Convert message to dictionary format containing 'instruction' field.

        Args:
            message: Message to convert.

        Returns:
            dict: Message dictionary with 'instruction' field.

        This method should be implemented by subclasses.
        """
        pass

    @abstractmethod
    async def send_message_once(self, text: str, **kwargs):
        """Send task progress via callback interface.

        Args:
            text (str): The message text to send.
            **kwargs: Additional keyword arguments.

        This method should be implemented by subclasses.
        """
        pass
    
    def post_result(self, payload: dict):
        """Post result to configured result URL.

        Args:
            payload (dict): Data payload to send.
        """
        try:
            headers = {
                'Content-Type': 'application/json; charset=UTF-8',
                'Accept': 'application/json'
            }
            # 不设 timeout 会卡到 OS TCP 重传 (~15min); 调用方可能在 sync 路径阻塞 receiver thread
            response = requests.post(
                self.result_url, json=payload, headers=headers, timeout=(3, 5),
            )

            if response.status_code == 200:
                logger.info(f"消息发送成功: {response.json()}")
            else:
                logger.info(f"发送反馈失败，HTTP状态码: {response.status_code}")
        except Exception as e:
            logger.info(f"发送反馈时出现错误: {e}")
            
    def send_message(self, text: str, task_status: str = "running", steps = [], **kwargs):
        """Send message with task status.

        Args:
            text (str): Message text to send.
            task_status (str): Task status. Defaults to "running".
            steps (list, optional): List of task steps.
            **kwargs: Additional keyword arguments.
        """
        if self._send_message_enable and self.enable_output:
            asyncio.get_event_loop().run_until_complete(
                self.send_message_once(text, task_status=task_status, steps=steps, **kwargs))
        else:
            logger.info(f"send_message() is disable, resume_send_message() to enable, now skip {text}")

    async def send_message_chunk(self, text: str, **kwargs):
        """Send message chunk (not supported, sends as single message).

        Args:
            text (str): Message chunk text.
            **kwargs: Additional keyword arguments.
        """
        logger.warning("send_message_chunk is not supported for FastAPIMsgClient; sending as a single message.")
        await self.send_message_once(text, **kwargs)
    
    def start(self):
        """Start FastAPI server."""
        if not self.enable_input:
            return

        logger.info("Starting FastAPIMsgClient...")
        self.reset()
        self.message_monitor.start()

        try:
            uvicorn.run(self.app, host=self.host, port=self.port)
        except KeyboardInterrupt:
            logger.info("遇到ctrl-c，FastAPIMsgClient 退出")

    def stop(self):
        """Stop the FastAPI server."""
        self.message_monitor.stop()
        logger.info("Stopping FastAPIMsgClient...")