# -*- coding: utf-8 -*-
#
# Copyright (c) 2023~2025 Beijing Innovation Center of Humanoid Robotics. All rights reserved.
#
import asyncio
import inspect
import json
import logging
import queue
import threading
import time
from collections.abc import AsyncIterator, Iterable

import websockets

from algo_tools.messages.base import BaseMsgClient
from algo_tools.utils.safe_queue import QueueDisable, SafeQueue
from algo_tools.websocket.socket_server import recv_msg, send_msg

logger = logging.getLogger(__name__)


class VoiceSocketClient(BaseMsgClient):
    """WebSocket client for voice message processing.

    Handles bidirectional communication with a voice server through WebSocket,
    supporting voice input and TTS output functionality.
    """

    def __init__(self,
                 uri="ws://localhost:8765",
                 voice_path="/voice",
                 tts_path="/ttsplay",
                 connect_timeout=3.0,
                 retry_voice=120,
                 retry_tts=1,
                 maxsize=1000,
                 recv_callback=None,
                 msg_preprocessor=None,
                 enable_input=True,
                 enable_output=True,
                 send_timeout=10.0,
                 wait_timeout=10.0):
        """Initialize VoiceSocketClient with WebSocket connection parameters.

        Args:
            uri (str): WebSocket server URI. Defaults to "ws://localhost:8765".
            voice_path (str): Path for voice input. Defaults to "/voice".
            tts_path (str): Path for TTS output. Defaults to "/ttsplay".
            connect_timeout (float): Connection timeout in seconds. Defaults to 3.0.
            retry_voice (int): Maximum retry attempts for voice connection. Defaults to 120.
            retry_tts (int): Maximum retry attempts for TTS connection. Defaults to 1.
            maxsize (int): Maximum size of message queue. Defaults to 1000.
            recv_callback (callable, optional): Callback for received messages.
            msg_preprocessor (callable, optional): Function for message preprocessing.
            enable_input (bool): Whether to enable message input. Defaults to True.
            enable_output (bool): Whether to enable message output. Defaults to True.
            send_timeout (float): Send timeout in seconds. Defaults to 10.0.
            wait_timeout (float): Wait timeout in seconds. Defaults to 10.0.
        """
        super().__init__(maxsize=maxsize, 
                         recv_callback=recv_callback,
                         msg_preprocessor=msg_preprocessor,
                         enable_input=enable_input,
                         enable_output=enable_output)
        assert voice_path.startswith("/") and tts_path.startswith("/")
        
        self.uri = uri
        self.voice_path = voice_path
        self.tts_path = tts_path
        self.connect_timeout = connect_timeout
        self.retry_voice = retry_voice
        self.retry_tts = retry_tts
        self.send_timeout = send_timeout
        self.wait_timeout = wait_timeout
        
        self._voice_uri = uri + voice_path
        self._tts_uri = uri + tts_path
        
        self.reset()

    def reset(self):
        """Reset client state and counters."""
        super().reset()
        self._retry_voice_cnt = 0
        self._retry_tts_cnt = 0
        self._running = True

        self._send_start = None
        self._pre_queue_done = True
        self._signal_queue = None
        self._send_thread = None
        self._text_queue = None
        self._send_state = None

    async def listen_voice(self):
        """Listen for voice messages from WebSocket server.

        Continuously attempts to reconnect if network connection is lost,
        with automatic retry logic and error handling.
        """
        while self._running and self._retry_voice_cnt <= self.retry_voice:
            try:
                async with websockets.connect(self._voice_uri, open_timeout=self.connect_timeout) as websocket:
                    logger.info(f"listen_voice: 成功连接到语音服务端，持续监听中: {self._voice_uri}")
                    # 重连成功后重置
                    self._retry_voice_cnt = 0
                    while self._running:
                        # 获取消息
                        try:
                            message = await websocket.recv()
                        # except asyncio.exceptions.CancelledError:
                        #     TODO: 加这个会卡死，遇到ctrl-c无法退出
                        #     return
                        except websockets.exceptions.ConnectionClosedError as err:
                            logger.warning(f'recv_msg: 警告, 网络异常关闭: {websocket.remote_address}: {err}')
                            # 异常关闭，尝试break去重连
                            break
                        except websockets.exceptions.ConnectionClosedOK:
                            # logger.info(f'recv_msg: 提示, 语音服务端主动断开连接，客户端正常退出: {websocket.remote_address}')
                            # 服务端主动关闭，尝试break去重连
                            break
                        
                        # 处理消息
                        msg_dict = self.get_msg_dict(message)
                        await self.process_message(msg_dict)

            except (ConnectionRefusedError, asyncio.TimeoutError, websockets.exceptions.InvalidMessage):
                logger.error(f"listen_voice: 连接语音服务端超时，请确保服务端已启动且网络通畅: {self._voice_uri}")
                await asyncio.sleep(1)
                self._retry_voice_cnt += 1
                logger.info(f"listen_voice: 尝试重连语音服务端: 第 {self._retry_voice_cnt}/{self.retry_voice} 次")

    async def _send_message_once(self, msg_dict_iter: Iterable):
        """Send message iterator once to TTS WebSocket.

        Args:
            msg_dict_iter (Iterable): Iterator of message dictionaries to send.
        """
        if not self._send_message_enable or not self.enable_output:
            logger.info(f"sending message is disable, run resume_send_message() to enable, now skip: {msg_dict_iter}")
            return

        self._send_state = None

        async def _send(_ws, _msg_dict):
            if not self._send_message_enable:
                if self._send_state is None:
                    logger.info(f"sending message is disable, run resume_send_message() to enable, now skip: {_msg_dict}")
                    # 发一个空的过去，通知服务端结束
                    _msg_dict = {}
                    self._send_state = "finished"
                else:
                    return

            assert isinstance(_msg_dict, dict), type(_msg_dict)
            _msg_str = json.dumps(_msg_dict, ensure_ascii=False)
            await send_msg(_ws, _msg_str)
            logger.info(f"send_message_once: 发送成功: {_msg_dict}")

        # 重置
        self._retry_tts_cnt = 0
        while self._running and self._retry_tts_cnt <= self.retry_tts:
            try:
                async with websockets.connect(self._tts_uri, open_timeout=self.connect_timeout) as websocket:
                    # logger.info(f"send_message_once: 成功连接到语音服务端的tts接口: {self._tts_uri}")
                    if isinstance(msg_dict_iter, SafeQueue):
                        while self._running:
                            try:
                                msg_dict = msg_dict_iter.get(self.wait_timeout)
                                if msg_dict is not None:
                                    await _send(websocket, msg_dict)
                                    msg_dict_iter.task_done()
                                else:
                                    break
                            except queue.Empty:
                                logger.warning(f"wait message timeout {self.send_timeout}s.")
                                # 禁止再传入
                                msg_dict_iter.disable_put()
                                # 发一个空的结束标志过去
                                await _send(websocket, {})
                                break
                    elif isinstance(msg_dict_iter, AsyncIterator) or inspect.isasyncgen(msg_dict_iter):
                        async for msg_dict in msg_dict_iter:
                            await _send(websocket, msg_dict)
                    else:
                        assert isinstance(msg_dict_iter, Iterable) , type(msg_dict_iter)
                        for msg_dict in msg_dict_iter:
                            await _send(websocket, msg_dict)

                    # 注意，要卡住，等待服务端收到消息后，主动断开连接
                    try:
                        # 创建一个新的任务，避免直接重用协程
                        recv_task = asyncio.create_task(recv_msg(websocket))
                        await recv_task
                    except Exception as e:
                        logger.error(f"Error during recv_msg: {e}")

                    # logger.info(f"发送完成，安全退出")
                    return
            except (ConnectionRefusedError, asyncio.TimeoutError):
                logger.error(f"send_message_once: 连接语音服务端超时，请确保服务端已启动且网络通畅: {self._tts_uri}")
                self._retry_tts_cnt += 1
                logger.info(f"send_message_once: 尝试重连语音服务端: 第 {self._retry_tts_cnt}/{self.retry_tts} 次")

    async def send_message_once(self,
                                text: str,
                                cmd: str = None,
                                **kwargs):
        """Send single message to TTS WebSocket.

        Args:
            text (str): Message text to send.
            cmd (str, optional): Command associated with the message.
            **kwargs: Additional keyword arguments.
        """
        await self._send_message_once(
            msg_dict_iter=[{"text": text, "cmd": cmd, **kwargs}]
        )

    async def send_message_stream(self, msg_dict_iter: Iterable):
        """Send message stream to TTS WebSocket.

        Args:
            msg_dict_iter (Iterable): Iterator of message dictionaries to send.
        """
        await self._send_message_once(msg_dict_iter)

    def send_message(self,
                     text: str,
                     cmd: str = None,
                     **kwargs):
        """Send message synchronously to TTS WebSocket.

        Args:
            text (str): Message text to send.
            cmd (str, optional): Command associated with the message.
            **kwargs: Additional keyword arguments.
        """
        if self._send_message_enable and self.enable_output:
            asyncio.get_event_loop().run_until_complete(
                self.send_message_once(text, cmd=cmd, **kwargs))
        else:
            logger.info("send_message() is disable or output is disable")
    
    def _send_worker(self):
        """Worker function for sending messages in separate thread."""
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        while self._running:
            signal, val = self._signal_queue.get()
            if signal == "SEND_QUEUE":
                loop.run_until_complete(self.send_message_stream(msg_dict_iter=val))
            elif signal == "STOP":
                break
            else:
                raise NotImplementedError(signal)

        logger.info("send_worker exit")

    async def send_message_chunk(self, text: str, cmd: str = None, finish: bool = True, **kwargs):
        """Send a chunk of a long text message.

        Divides long text into multiple chunks and sends them sequentially.
        Sets finish=True when sending the final chunk.

        Args:
            text (str): Text chunk to send.
            cmd (str, optional): Command associated with the message.
            finish (bool): Whether this is the final chunk. Defaults to True.
            **kwargs: Additional keyword arguments.
        """
        
        def _put_to_new_queue(_msg_dict):
            if self._signal_queue is None:
                self._signal_queue = queue.Queue()
                self._send_thread = threading.Thread(target=self._send_worker, daemon=True)
                self._send_thread.start()
            
            self._text_queue = SafeQueue()    
            self._text_queue.put(_msg_dict)
            self._signal_queue.put(("SEND_QUEUE", self._text_queue))    
            self._send_start = time.time()
        
        # 发送窗口时间太长会导致断联，强行结束发送
        if self._send_start is not None and (time.time() - self._send_start >= self.send_timeout):
            logger.info(f"连续发送超时 {self.send_timeout}s，强行截断，finish置为True")
            finish = True
        
        msg_dict = dict(text=text, cmd=cmd, finish=finish, **kwargs)
        
        # 前一次发送结束，开设新的队列
        if self._text_queue is None or self._pre_queue_done:
            _put_to_new_queue(msg_dict)
        else:
            try:
                self._text_queue.put(msg_dict)
            except QueueDisable:
                # 原来的队列失效，则放到新队列去发送
                _put_to_new_queue(msg_dict)
        
        # 文本段结束，结束发送
        if finish:
            # 通知发送端不要再等了
            self._text_queue.put(None)
            self._pre_queue_done = True 
            self._send_start = None
        else:
            self._pre_queue_done = False

    def start(self):
        """Start the voice WebSocket client."""
        self.reset()
        if not self.enable_input:
            return

        self.message_monitor.start()

        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        try:
            loop.run_until_complete(self.listen_voice())
        except KeyboardInterrupt:
            logger.info("遇到ctrl-c，语音客户端退出")

    def stop(self):
        """Stop the voice WebSocket client."""
        self._running = False
        self.message_monitor.stop()
        if self._signal_queue is not None:
            self._signal_queue.put(("STOP", None))
        if self._send_thread is not None:
            self._send_thread.join()
            self._send_thread = None