# -*- coding: utf-8 -*-
#
# Copyright (c) 2023~2025 Beijing Innovation Center of Humanoid Robotics. All rights reserved.
#

import asyncio
import logging
import threading
from collections.abc import Iterable
from typing import List

from algo_tools.messages.base import BaseMsgClient

logger = logging.getLogger(__name__)


class ComposeMsgClient(BaseMsgClient):
    """Composite message processing client that manages multiple client instances.

    Supports controlling multiple message clients through a single interface,
    enabling broadcasting messages to all clients simultaneously.
    """

    def __init__(self,
                 client_list: List[BaseMsgClient],
                 maxsize: int = 1000,
                 recv_callback=None,
                 msg_preprocessor=None,
                 enable_input: bool = True,
                 enable_output: bool = True):
        """Initialize ComposeMsgClient with list of client instances.

        Args:
            client_list (List[BaseMsgClient]): List of client instances to manage.
            maxsize (int): Maximum size of message queue. Defaults to 1000.
            recv_callback (callable, optional): Callback for received messages.
            msg_preprocessor (callable, optional): Function for message preprocessing.
            enable_input (bool): Whether to enable message input. Defaults to True.
            enable_output (bool): Whether to enable message output. Defaults to True.
        """
        
        super().__init__(maxsize=maxsize, 
                         recv_callback=recv_callback,
                         msg_preprocessor=msg_preprocessor,
                         enable_input=enable_input,
                         enable_output=enable_output)

        # 客户端实例列表
        self.client_list = client_list
        self._threads = []
        
        for client in self.client_list:
            logger.info(f"注意：{client}的 msg_preprocessor 已被置空，且recv_callback 已指向本实例的 process_message 方法")
            client.msg_preprocessor = None
            client.register_callback(self.process_message)

    def get_msg_dict(self, message):
        """Convert message to dictionary format.

        Args:
            message: Message to convert.

        Returns:
            dict: Message dictionary.

        Raises:
            NotImplementedError: This method is not supported by ComposeMsgClient.
        """
        raise NotImplementedError("ComposeInstructListener 不支持的消息转换")
    
    async def send_message_once(self,
                                text: str,
                                **kwargs):
        """Send message once to all enabled clients.

        Args:
            text (str): Message text to send.
            **kwargs: Additional keyword arguments.

        Broadcasts the message to all clients that have output enabled.
        """
        if not self._send_message_enable:
            logger.info(f"send_message() is disable, resume_send_message() to enable, now skip: {text}")
            return

        # 向所有启用输出的客户端发送消息
        for client in self.client_list:
            if client.enable_output:
                try:
                    # 根据客户端类型调用不同的发送方法
                    await client.send_message_once(text, **kwargs)
                except Exception as e:
                    logger.error(f"向客户端发送消息失败: {e}", exc_info=True)
    
    async def send_message_stream(self, msg_dict_iter: Iterable):
        """Send message stream.

        Args:
            msg_dict_iter (Iterable): Iterator of message dictionaries.

        Raises:
            NotImplementedError: This method is not supported by ComposeMsgClient.
        """
        raise NotImplementedError("ComposeInstructListener 不支持的消息流发送")
    
    async def send_message_chunk(self, text: str, **kwargs):
        """Send message chunk (not supported, sends as single message).

        Args:
            text (str): Message chunk text.
            **kwargs: Additional keyword arguments.
        """
        if not self._send_message_enable:
            logger.info(f"send_message() is disable, resume_send_message() to enable, now skip: {text}")
            return

        # 向所有启用输出的客户端发送消息
        for client in self.client_list:
            if client.enable_output:
                try:
                    # 根据客户端类型调用不同的发送方法
                    await client.send_message_chunk(text, **kwargs)
                except Exception as e:
                    logger.error(f"向客户端发送消息失败: {e}", exc_info=True)

    def send_message(self, text: str, **kwargs):
        """Send message synchronously.

        Args:
            text (str): Message text to send.
            **kwargs: Additional keyword arguments.
        """
        if self._send_message_enable:
            asyncio.get_event_loop().run_until_complete(
                self.send_message_once(text, **kwargs))
        else:
            logger.info(f"send_message() is disable, resume_send_message() to enable, now skip {text}")

    def set_current_message(self, message):
        """Set current message context and synchronize to all clients.

        Args:
            message: Message to set as current context.
        """
        super().set_current_message(message)

        if message is not None:
            for client in self.client_list:
                client.set_current_message(message)
    
    def start(self):
        """Start the composite message listener.

        Initializes and starts all client instances in separate threads,
        then runs the event loop to handle asynchronous operations.
        """
        logger.info("Starting ComposeMsgClient...")
        self.reset()
        self.message_monitor.start()

        # 确保主线程有一个事件循环
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        
        # 创建客户端启动的线程
        self._threads = []

        # 为每个客户端创建启动线程
        for i, client in enumerate(self.client_list):
            thread = threading.Thread(
                target=self._start_client,
                args=(client, f"client-{i}"),
                daemon=True
            )
            self._threads.append(thread)

        # 启动所有线程
        for thread in self._threads:
            thread.start()

        # 等待所有线程结束
        try:
            # 使用异步方式等待，而不是循环检查线程状态
            # 这允许主线程处理其他异步任务
            if self._threads:
                loop.run_forever()
            else:
                logger.info("没有活跃的客户端线程，复合监听器将退出")
        except KeyboardInterrupt:
            logger.info("遇到ctrl-c，复合监听器退出")
            self.stop()

    def _start_client(self, client, client_name):
        """Start a client in a separate thread.

        Args:
            client: Client instance to start.
            client_name (str): Name identifier for the client.
        """
        try:
            logger.info(f"正在启动客户端: {client_name}")
            client.start()
        except Exception as e:
            logger.error(f"客户端 {client_name} 启动失败: {e}", exc_info=True)

    def stop(self):
        """Stop the composite message listener.

        Stops all client instances and waits for all threads to complete.
        """
        logger.info("Stopping ComposeMsgClient...")
        self._running = False
        self.message_monitor.stop()

        # 停止所有客户端
        for client in self.client_list:
            try:
                client.stop()
            except Exception as e:
                logger.error(f"停止客户端失败: {e}")

        # 等待所有线程结束
        for thread in self._threads:
            thread.join()
        logger.info("所有客户端线程已结束")

