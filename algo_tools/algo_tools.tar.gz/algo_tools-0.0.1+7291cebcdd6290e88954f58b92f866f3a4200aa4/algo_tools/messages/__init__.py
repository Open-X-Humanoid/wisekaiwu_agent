# -*- coding: utf-8 -*-
#
# Copyright (c) 2023~2025 Beijing Innovation Center of Humanoid Robotics. All rights reserved.
#

"""Message processing client implementations.

This module provides various message client implementations for handling
different types of communication patterns including WebSocket, FastAPI,
and composite message processing.
"""

from algo_tools.messages.base import BaseMsgClient, BaseFastAPIMsgClient
from algo_tools.messages.voice_socket import VoiceSocketClient
from algo_tools.messages.compose import ComposeMsgClient
