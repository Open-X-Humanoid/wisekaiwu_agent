# -*- coding: utf-8 -*-
#
# Copyright (c) 2023~2025 Beijing Innovation Center of Humanoid Robotics. All rights reserved.
#

"""Asynchronous iterator utilities."""

import asyncio


class AsyncBlockingIterator:
    """Asynchronous iterator that supports blocking put operations.

    This class provides an async iterator interface with methods for
    adding items and stopping iteration.
    """

    def __init__(self):
        """Initialize the AsyncBlockingIterator with an async queue."""
        self.q = asyncio.Queue()
        # self._stop = False

    async def put(self, item):
        """Put an item into the iterator queue.

        Args:
            item: Item to add to the iterator.
        """
        await self.q.put(item)

    async def stop(self):
        """Stop the iterator by putting None as sentinel value."""
        await self.q.put(None)

    def __aiter__(self):
        """Return the async iterator object."""
        return self

    async def __anext__(self):
        """Get the next item from the iterator.

        Returns:
            The next item in the iteration.

        Raises:
            StopAsyncIteration: When iteration is complete.
        """
        item = await self.q.get()
        if item is None:
            raise StopAsyncIteration
        return item

async def producer(it):
    """Example producer function that generates items for the iterator.

    Args:
        it (AsyncBlockingIterator): The iterator to produce items for.
    """
    for i in range(5):
        await asyncio.sleep(0.5)  # 模拟异步生产
        print(f'Produced: {i}')
        await it.put(i)
    await it.stop()

async def consumer(it):
    """Example consumer function that processes items from the iterator.

    Args:
        it (AsyncBlockingIterator): The iterator to consume items from.
    """
    async for item in it:
        print(f'Consumed: {item}')
        await asyncio.sleep(1)

async def main():
    """Main function demonstrating producer-consumer pattern."""
    it = AsyncBlockingIterator()

    # 启动 producer 和 consumer
    await asyncio.gather(
        producer(it),
        consumer(it)
    )


if __name__ == "__main__":
    asyncio.run(main())
