# -*- coding: utf-8 -*-
#
# Copyright (c) 2023~2025 Beijing Innovation Center of Humanoid Robotics. All rights reserved.
#

"""Thread-safe queue with enable/disable functionality."""

import queue
import threading


class QueueDisable(Exception):
    """Exception raised when trying to put items into a disabled queue."""
    pass


class SafeQueue(queue.Queue):
    """Thread-safe queue that can be enabled/disabled for putting items.

    Inherits from queue.Queue and adds functionality to enable/disable
    putting new items into the queue.
    """

    def __init__(self, maxsize=0):
        """Initialize SafeQueue.

        Args:
            maxsize (int): Maximum size of the queue. Defaults to 0 (unlimited).
        """
        super().__init__(maxsize)
        self._enable_flag = True
        self._put_lock = threading.Lock()

    def enable_put(self):
        """Enable putting items into the queue."""
        with self._put_lock:
            self._enable_flag = True

    def disable_put(self):
        """Disable putting items into the queue."""
        with self._put_lock:
            self._enable_flag = False

    def put(self, item, block=True, timeout=None):
        """Put an item into the queue if enabled.

        Args:
            item: Item to put into the queue.
            block (bool): Whether to block if queue is full. Defaults to True.
            timeout (float, optional): Timeout in seconds. Defaults to None.

        Raises:
            QueueDisable: If putting is disabled.
        """
        if self._enable_flag:
            super().put(item, block=block, timeout=timeout)
        else:
            raise QueueDisable
