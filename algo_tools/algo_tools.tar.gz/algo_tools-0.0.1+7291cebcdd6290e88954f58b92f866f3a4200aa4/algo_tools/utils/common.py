# -*- coding: utf-8 -*-
#
# Copyright (c) 2023~2025 Beijing Innovation Center of Humanoid Robotics. All rights reserved.
#

"""Common utility functions."""

import time
import base64
import io
from PIL import Image
import re
import logging

logger = logging.getLogger()

__all__ = ["get_time_stamp", "encode_image", "split_str"]

# 分隔符删掉，不保留，要保留则加上()，即 r'([，。？！、；,?;!])'
DEFAULT_SEG_REGEX = r'[，。？！、；,?;!]'


def get_time_stamp():
    """Get current timestamp in milliseconds.

    Returns:
        int: Current timestamp rounded to milliseconds.
    """
    time_stamp = time.time()
    return int(round(time_stamp * 1000))


def encode_image(image_path, new_size=None, max_size=None):
    """Open, resize, and encode image as base64 string.

    Args:
        image_path (str): Path to the image file.
        new_size (tuple or list, optional): New size (width, height) to resize image to.
        max_size (int, optional): Maximum allowed size in pixels (width * height).

    Returns:
        str: Base64 encoded image string.

    Raises:
        AssertionError: If new_size is not a tuple/list of length 2.
    """
    # Open the image and adjust its size
    with Image.open(image_path) as img:
        # Convert RGBA to RGB if necessary
        if img.mode == 'RGBA':
            img = img.convert('RGB')
        
        logger.info(f"Original Image Size: {img.size}")
        
        # Resize to specified dimensions if provided
        if new_size is not None:
            assert isinstance(new_size, (list, tuple)) and len(new_size) == 2, "new_size must be a tuple or list of length 2"
            img = img.resize(new_size)
            logger.info(f"Resized Image Size: {img.size}")

        # Ensure the image does not exceed the maximum size
        if max_size and img.size[0] * img.size[1] > max_size:
            scale_factor = (max_size / (img.size[0] * img.size[1])) ** 0.5
            new_width = int(img.size[0] * scale_factor)
            new_height = int(img.size[1] * scale_factor)
            img = img.resize((new_width, new_height))
            logger.info(f"Scaled Down Image Size: {img.size}")

        # 使用 io.BytesIO 将图像保存为二进制流
        buffer = io.BytesIO()
        img.save(buffer, format="JPEG")
        buffer.seek(0)
        
        # 读取二进制流并转换为 base64 编码字符串
        return base64.b64encode(buffer.read()).decode('utf-8')


def split_str(text, seg_regx=DEFAULT_SEG_REGEX, seg_len=None, separator=""):
    """Split text into segments using regex pattern.

    Args:
        text (str): Text to split.
        seg_regx (str): Regex pattern for splitting. Defaults to DEFAULT_SEG_REGEX.
        seg_len (int, optional): Maximum length for each segment. If None, no length limit.
        separator (str): Separator to join segments. Defaults to "".

    Returns:
        list: List of text segments.

    Raises:
        AssertionError: If seg_len is not None and <= 0.
    """
    assert seg_len is None or seg_len > 0, seg_len
    segments = re.split(seg_regx, text)
    if len(segments) > 1 and segments[-1] == "":
        segments = segments[:-1]

    if seg_len is None:
        return segments

    new_segments = []
    cur_text = segments[0]
    for i in range(1, len(segments)):
        if len(cur_text) + len(segments[i]) < seg_len:
            cur_text += separator + segments[i]
        else:
            new_segments.append(cur_text)
            cur_text = segments[i]

    new_segments.append(cur_text)
    return new_segments
