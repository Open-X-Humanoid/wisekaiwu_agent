# -*- coding: utf-8 -*-
#
# Copyright (c) 2023~2025 Beijing Innovation Center of Humanoid Robotics. All rights reserved.
#
import asyncio
import inspect
import logging
import queue
import threading
import time
import traceback

logger = logging.getLogger()


class MessageMonitor:
    """Thread-safe message monitoring and processing system.

    Monitors incoming messages, applies callbacks, and provides methods
    for retrieving messages with timeout handling.
    """

    def __init__(self,
                 recv_callback=None,
                 recv_timeout=None,
                 timeout_callback=None,
                 maxsize=10000):
        """Initialize MessageMonitor with callbacks and configuration.

        Args:
            recv_callback (callable, optional): Callback function for received messages.
            recv_timeout (float, optional): Timeout in seconds for receiving messages.
            timeout_callback (callable, optional): Callback for timeout events.
            maxsize (int): Maximum size of message queue. Defaults to 10000.

        Raises:
            AssertionError: If recv_callback is provided but not callable.
            AssertionError: If recv_timeout is provided but timeout_callback is not callable.
        """
        if recv_callback is not None:
            assert callable(recv_callback), recv_callback
        if recv_timeout is not None:
            assert callable(timeout_callback), timeout_callback

        self.recv_timeout = recv_timeout
        self.recv_callback = recv_callback
        self.timeout_callback = timeout_callback

        self.message_queue = queue.Queue(maxsize=maxsize)
        self.last_received_time = time.time()
        self.running = True # 运行标志，用于安全结束线程

        # 创建接收方线程
        self.receiver_thread = threading.Thread(target=self.receiver)
        # 设置守护线程
        self.receiver_thread.daemon = True

        self._accept_new = True

        # 便于获取到最新消息，因为queue没法获取到最新元素，dequeue没法阻塞
        # self._latest_msg_event = None
        self._latest_msg_queue = queue.LifoQueue(maxsize=1)
        self._request_latest = False

    def receiver(self):
        """Main receiver loop that processes incoming messages.

        Runs in a separate thread, monitoring the message queue and
        applying callbacks to received messages. Handles both
        synchronous and asynchronous callbacks.
        """
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        # logger.info(f"receiver loop id: {id(loop)}")

        while self.running:
            try:
                # 检查是否有新消息
                message = self.message_queue.get(timeout=1)
                self.last_received_time = time.time()
                if message is not None and self.recv_callback is not None:
                    try:
                        if inspect.iscoroutinefunction(self.recv_callback):
                            asyncio.run(self.recv_callback(message))
                        else:
                            self.recv_callback(message)
                        # self.recv_callback(message)
                    except Exception:
                        # 发生任何错误都不要崩溃
                        logger.error(traceback.format_exc())
                    # print(f"Received message: {message}")
            except queue.Empty:
                # 如果超过指定时间未收到消息，则执行回调函数
                if self.recv_timeout is not None and \
                    time.time() - self.last_received_time > self.recv_timeout:
                    self.timeout_callback()
                    self.last_received_time = time.time() # 重置时间

        loop.close()
    
    def get_msg(self, timeout=None):
        """Get a message from the queue.

        Args:
            timeout (float, optional): Timeout in seconds. Defaults to None (no timeout).

        Returns:
            Message from queue, or None if timeout occurs.
        """
        try:
            message = self.message_queue.get(timeout=timeout)
        except queue.Empty:
            message = None
        return message

    def get_latest_msg(self, timeout=None):
        """Get the latest message.

        Args:
            timeout (float, optional): Timeout in seconds. Defaults to None (no timeout).

        Returns:
            Latest message received, or None if timeout occurs.
        """
        self._request_latest = True
        _accept = self._accept_new
        self._accept_new = True

        # 阻塞，直到收到新消息
        try:
            message = self._latest_msg_queue.get(timeout=timeout)
        except queue.Empty:
            message = None

        # 恢复
        self._accept_new = _accept
        self._request_latest = False
        return message
    
    def pending(self):
        """Pause accepting new messages."""
        self._accept_new = False

    def resume(self):
        """Resume accepting new messages."""
        self._accept_new = True

    def send(self, message=None):
        """Send a message to the monitor.

        Args:
            message: Message to send to the monitor.
        """
        if self.running:
            # 有人请求最新消息
            if self._accept_new:
                if self._request_latest:
                    self._latest_msg_queue.put(message)
                else:
                    self.message_queue.put(message)
            else:
                logger.warning(f"MessageMonitor.send: 目前不接受新消息，跳过: {message}")
        else:
            logger.error(f"MessageMonitor.send: 错误，目前不处于运行状态: {message}")

    def start(self):
        """Start the message monitor."""
        self.running = True
        self._accept_new = True
        self.receiver_thread.start()

    def stop(self):
        """Stop the message monitor and wait for receiver thread to complete."""
        self.running = False
        self._accept_new = False
        self.receiver_thread.join()
        logger.info("MessageMonitor.stop: stopped.")
